package com.test.jdbc;

public class MysqlTest {
public static void main(String[] args) {
	System.out.println(MysqlConnection.getInstanceOfMysql());
}
}
