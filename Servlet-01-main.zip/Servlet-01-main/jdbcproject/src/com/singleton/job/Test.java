package com.singleton.job;

public class Test {
	public static void main(String[] args) {
		/*for(int i =0;i<=10;i++){ 
		Abc ob =  Abc.getInstance();
		System.out.println(ob);
		//Abc ob1 = Abc.getInstance();
		}*/
		Abc.getInstance();
	}
}
